# Colors

- primary background color: #111214
- secondary background color: #1E2126

- primary button color: #B6FF56
- secondary button color: #B8ECB9


- primary text color: #F4F5F9 (white)
- secondary text color: #636466 (gray)