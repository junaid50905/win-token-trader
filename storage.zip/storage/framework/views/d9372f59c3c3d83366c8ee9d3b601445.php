<footer class="page-footer">
            <p class="mb-0">Copyright © 2021. All right reserved.</p>
        </footer><?php /**PATH E:\xamppforprojects\htdocs\WinTokenTrader\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>