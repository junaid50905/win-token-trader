<!doctype html>
<html lang="en">

<?php echo $__env->make('admin.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body class="bg-theme bg-theme2">
    <!--wrapper-->
    <div class="wrapper">

        <!--sidebar wrapper -->
        <?php echo $__env->make('admin.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--end sidebar wrapper -->

        <!--start header -->
        <?php echo $__env->make('admin.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--end header -->

        <!--start page wrapper -->
        <div class="page-wrapper">
            <?php echo $__env->yieldContent('page-content'); ?>
        </div>
        <!--end page wrapper -->

        <!--start overlay-->
        <div class="overlay toggle-icon"></div>
        <!--end overlay-->

        <!--Start Back To Top Button-->
        <a href="javaScript:;" class="back-to-top">
            <i class='bx bxs-up-arrow-alt'></i></a>
        <!--End Back To Top Button-->

        <?php echo $__env->make('admin.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <!--end wrapper-->

    <!--start switcher-->
    <?php echo $__env->make('admin.partials.theme-customizer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!--end switcher-->

    <!--scripts files start-->
    <?php echo $__env->make('admin.partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!--scripts files end -->

</body>

</html>
<?php /**PATH E:\xamppforprojects\htdocs\WinTokenTrader\resources\views\admin\layouts\app.blade.php ENDPATH**/ ?>